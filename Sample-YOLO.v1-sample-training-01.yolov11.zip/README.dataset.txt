# Sample-YOLO > sample-training-01
https://universe.roboflow.com/bpnai/sample-yolo

Provided by a Roboflow user
License: MIT

